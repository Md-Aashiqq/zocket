
import Dashboard from './Pages/Dashboard';
import "./Styles/App.scss";

function App() {
  return (
    <Dashboard />
  );
}

export default App;
